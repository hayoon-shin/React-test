//1. 변수
let age = 100;

//2. 상수
const NAME = "fdshsda";

//3. 변수명명규칙 (자바 낙타표기법), 숫자는 뒤에, 앞에는 영문자만, 특수문자는 $, _만 허용
let _name = 10;

//4. 변수명에 예약어 쓰지마라
let if1 = 10;

//5. 변수명 - 낙타표기법, 상수 - 대문자, 단어(가독성있게 설계)
let studentCount = 100;

let undefinedvalue; 
console.log(undefinedvalue);
